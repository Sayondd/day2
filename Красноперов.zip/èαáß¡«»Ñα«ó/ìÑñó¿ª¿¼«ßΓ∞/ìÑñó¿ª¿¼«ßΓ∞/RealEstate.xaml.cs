﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Недвижимость
{
    /// <summary>
    /// Логика взаимодействия для RealEstate.xaml
    /// </summary>
    public partial class RealEstate : Window
    {
        public RealEstate()
        {
            InitializeComponent();
            DGVapartament.ItemsSource = App.entities.apartments.ToList();
            DGVhous.ItemsSource = App.entities.houses.ToList();
            DGVland.ItemsSource = App.entities.lands.ToList();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            AddHous hous = new AddHous();
            hous.ShowDialog();
            DGVhous.ItemsSource = App.entities.houses.ToList();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            AddApartament apartament = new AddApartament();
            apartament.ShowDialog();
            DGVapartament.ItemsSource = App.entities.apartments.ToList();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            AddLand land = new AddLand();
            land.ShowDialog();
            DGVland.ItemsSource = App.entities.lands.ToList();
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            var edit = DGVhous.SelectedItem as bd.house;
            if (edit != null)
            {
                EditHouse house = new EditHouse(edit);
                house.ShowDialog();
            }
            else
            {
                MessageBox.Show("Не выбрана строка для редактирования");
            }
            DGVhous.ItemsSource = App.entities.houses.ToList();
        }

        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            var edit = DGVapartament.SelectedItem as bd.apartment;
            if (edit != null)
            {
                EditApartment apartment = new EditApartment(edit);
                apartment.ShowDialog();
            }
            else
            {
                MessageBox.Show("Не выбрана строка для редактирования");
            }
            DGVhous.ItemsSource = App.entities.apartments.ToList();
        }

        private void Button_Click_6(object sender, RoutedEventArgs e)
        {
            var edit = DGVland.SelectedItem as bd.land;
            if (edit != null)
            {
                EditLand land = new EditLand(edit);
                land.ShowDialog();
            }
            else
            {
                MessageBox.Show("Не выбрана строка для редактирования");
            }
            DGVland.ItemsSource = App.entities.lands.ToList();
        }

        private void Button_Click_7(object sender, RoutedEventArgs e)
        {
            try
            {
                var del = DGVhous.SelectedItem as bd.house;
                if (del != null)
                {
                    MessageBoxResult result = MessageBox.Show("Вы уверены что хотите удалить данные?", "Подтверждение удаления", MessageBoxButton.YesNo);
                    if (result == MessageBoxResult.Yes)
                    {
                        App.entities.houses.Remove(del);
                        App.entities.SaveChanges();
                        DGVhous.ItemsSource = App.entities.houses.ToList();
                    }
                }
                else
                {
                    MessageBox.Show("Вы не выбрали строку для удаления");
                }
            }
            catch
            { }
        }

        private void Button_Click_8(object sender, RoutedEventArgs e)
        {
            try
            {
                var del = DGVapartament.SelectedItem as bd.apartment;
                if (del != null)
                {
                    MessageBoxResult result = MessageBox.Show("Вы уверены что хотите удалить данные?", "Подтверждение удаления", MessageBoxButton.YesNo);
                    if (result == MessageBoxResult.Yes)
                    {
                        App.entities.apartments.Remove(del);
                        App.entities.SaveChanges();
                        DGVapartament.ItemsSource = App.entities.apartments.ToList();
                    }
                }
                else
                {
                    MessageBox.Show("Вы не выбрали строку для удаления");
                }
            }
            catch
            { }
        }

        private void Button_Click_9(object sender, RoutedEventArgs e)
        {
            try
            {
                var del = DGVland.SelectedItem as bd.land;
                if (del != null)
                {
                    MessageBoxResult result = MessageBox.Show("Вы уверены что хотите удалить данные?", "Подтверждение удаления", MessageBoxButton.YesNo);
                    if (result == MessageBoxResult.Yes)
                    {
                        App.entities.lands.Remove(del);
                        App.entities.SaveChanges();
                        DGVland.ItemsSource = App.entities.lands.ToList();
                    }
                }
                else
                {
                    MessageBox.Show("Вы не выбрали строку для удаления");
                }
            }
            catch
            { }
        }

        private void search_TextChanged(object sender, TextChangedEventArgs e)
        {
            var searchHous = App.entities.houses.Where(c => c.Address_City.
                Contains(search.Text)).ToList();
            DGVhous.ItemsSource = searchHous;
        }
    }
}
