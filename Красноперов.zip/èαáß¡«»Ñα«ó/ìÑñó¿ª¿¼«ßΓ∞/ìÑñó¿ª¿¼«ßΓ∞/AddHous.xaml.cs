﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Xml.Linq;
using Недвижимость.bd;

namespace Недвижимость
{
    /// <summary>
    /// Логика взаимодействия для AddHous.xaml
    /// </summary>
    public partial class AddHous : Window
    {
        public AddHous()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (numHous.Text == "" || rayon.Text == "" || numApart.Text == "" || shirota.Text == "" || protyazh.Text == "" || etazhi.Text == "" || ploshad.Text == "")
                {
                    MessageBox.Show("Не все поля заполнены");
                }
                else
                {
                    house house = new house
                    {
                        Address_City = City.Text,
                        Address_House = Convert.ToInt32(numHous.Text),
                        IdDistricts = Convert.ToInt32(rayon.Text),
                        Address_Number = Convert.ToInt32(numApart.Text),
                        Coordinate_latitude = Convert.ToInt32(shirota.Text),
                        Coordinate_longitude = Convert.ToInt32(protyazh.Text),
                        TotalFloors = Convert.ToInt32(etazhi.Text),
                        TotalArea = ploshad.Text

                };
                    App.entities.houses.Add(house);
                    App.entities.SaveChanges();
                    MessageBox.Show("Данные успешно добавлены!");
                    Close();
                }
            }
            catch
            { }
        }
    }
}
