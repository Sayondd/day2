﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Недвижимость.bd;

namespace Недвижимость
{
    /// <summary>
    /// Логика взаимодействия для AddLand.xaml
    /// </summary>
    public partial class AddLand : Window
    {
        public AddLand()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (City.Text == "" || numHous.Text == "" || rayon.Text == "" || shirota.Text == "" || protyazh.Text == "" || ploshad.Text == "")
                {
                    MessageBox.Show("Не все поля заполнены");
                }
                else
                {
                    land land = new land
                    {
                      Address_City = City.Text,
                      Address_House = Convert.ToInt32(numHous.Text),
                      IdDistricts = Convert.ToInt32(rayon.Text),
                      Address_Number = Convert.ToInt32(num.Text),
                      Coordinate_latitude = Convert.ToInt32(shirota.Text),
                      Coordinate_longitude = Convert.ToInt32(protyazh.Text),
                      TotalArea = Convert.ToInt32(ploshad.Text)
                    };
                    App.entities.lands.Add(land);
                    App.entities.SaveChanges();
                    MessageBox.Show("Данные успешно добавлены!");
                    Close();
                }
            }
            catch
            { }
        }
    }
}
