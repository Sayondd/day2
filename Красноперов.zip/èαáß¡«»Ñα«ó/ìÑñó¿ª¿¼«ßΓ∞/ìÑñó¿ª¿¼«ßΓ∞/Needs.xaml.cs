﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Недвижимость
{
    /// <summary>
    /// Логика взаимодействия для Needs.xaml
    /// </summary>
    public partial class Needs : Window
    {
        public Needs()
        {
            InitializeComponent();
            DGVH.ItemsSource = App.entities.house_demands.ToList();
            DGVA.ItemsSource = App.entities.apartment_demands.ToList();
            DGVZ.ItemsSource = App.entities.land_demands.ToList();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
