﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Недвижимость
{
    /// <summary>
    /// Логика взаимодействия для AddLand_demands.xaml
    /// </summary>
    public partial class AddLand_demands : Window
    {
        public AddLand_demands()
        {
            InitializeComponent();
        }
    }
}
