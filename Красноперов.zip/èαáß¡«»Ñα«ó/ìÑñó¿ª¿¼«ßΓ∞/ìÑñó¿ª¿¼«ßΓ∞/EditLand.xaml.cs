﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Недвижимость
{
    /// <summary>
    /// Логика взаимодействия для EditLand.xaml
    /// </summary>
    public partial class EditLand : Window
    {
        int id;
        public EditLand(bd.land land)
        {
            InitializeComponent();
            DataContext = land;
            id = land.Id;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var edit = App.entities.lands.FirstOrDefault(c => c.Id == id);
                edit.Address_City = City.Text;
                edit.Address_House = Convert.ToInt32(numHous.Text);
                edit.IdDistricts = Convert.ToInt32(rayon.Text);
                edit.Address_Number = Convert.ToInt32(num.Text);
                edit.Coordinate_latitude = Convert.ToInt32(shirota.Text);
                edit.Coordinate_longitude = Convert.ToInt32(protyazh.Text);
                edit.TotalArea = Convert.ToInt32(ploshad.Text);
                App.entities.SaveChanges();
                MessageBox.Show("Данные успешно изменены");
                Close();
            }
            catch
            { }
        }
    }
}
